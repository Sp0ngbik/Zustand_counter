import React, {useEffect, useState} from 'react';
import './App.css';
import Button from "./components/Button/Button";
import Setting from "./components/Setting/Setting";

export type T_CounterSettings = {
    counter: number,
    minValue: number,
    maxValue: number,
    informMessage: string,
    inSettingStatus: boolean
}

function App() {
    const [settingCounter, setSettingsCounter] = useState<T_CounterSettings>({
        counter: Number(localStorage.getItem('minValue')) || 0,
        minValue: Number(localStorage.getItem('minValue')) || 0,
        maxValue: Number(localStorage.getItem('maxValue')) || 5,
        informMessage: '',
        inSettingStatus: false
    })
    let localMaxValue
    let localMinValue
    useEffect(() => {
        localStorage.setItem('maxValue', settingCounter.maxValue.toString())
        localStorage.setItem('minValue', settingCounter.minValue.toString())
    }, [settingCounter]);
    const onMaxValue = () => settingCounter.maxValue === settingCounter.counter
    const increaseValue = () => {
        setSettingsCounter({...settingCounter, counter: settingCounter.counter + 1})

    }
    const resetValue = () => {
        setSettingsCounter({...settingCounter, counter: settingCounter.counter = settingCounter.minValue})
    }
    const valueValidator = () => {
        return settingCounter.minValue < 0 || settingCounter.minValue >= settingCounter.maxValue
    }
    return (
        <div className="App">
            <div>
                <Setting
                    settingCounter={settingCounter}
                    setSettingCounter={setSettingsCounter}
                    valueValidator={valueValidator}
                />
            </div>
            <div className='counter_wrapper'>
                {settingCounter.informMessage ?
                    <div
                        className={valueValidator() ? 'errorMessage' : 'informMessage'}>{settingCounter.informMessage}</div> :
                    <div
                        className={settingCounter.maxValue === settingCounter.counter ? 'counterError' : 'counterStyle'}>{settingCounter.counter}</div>}
                <div className='button_section'>
                    <Button title={'Inc'} inSettingMode={settingCounter.inSettingStatus} disabled={onMaxValue}
                            callback={increaseValue}/>
                    <Button title={'Reset'} disabled={() => settingCounter.inSettingStatus} callback={resetValue}/>
                </div>
            </div>
        </div>
    );
}

export default App;
