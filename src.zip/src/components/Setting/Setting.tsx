import React, {ChangeEvent, FC, useEffect} from 'react';
import Button from "../Button/Button";
import style from './setting.module.css'
import {T_CounterSettings} from "../../App";

type T_SettingProps = {
    settingCounter: T_CounterSettings,
    setSettingCounter: (settingCounter: T_CounterSettings) => void
    valueValidator: () => boolean
}
const Setting: FC<T_SettingProps> = ({
                                         settingCounter,
                                         setSettingCounter,
                                         valueValidator,
                                     }) => {

    const setSettingValue = () => {
        setSettingCounter({
            ...settingCounter,
            counter: settingCounter.minValue,
            inSettingStatus: false,
            informMessage: ''
        })
    }
    const maxValueConfigHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setSettingCounter({...settingCounter, maxValue: Number(e.currentTarget.value)})
    }
    const minValueConfigHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setSettingCounter({...settingCounter, minValue:  Number(e.currentTarget.value)})
    }
    const onCheckValidationText = () => {
        return valueValidator() ?
            setSettingCounter({...settingCounter, informMessage: settingCounter.informMessage = 'Invalid values'})
            : setSettingCounter({
                ...settingCounter,
                informMessage: settingCounter.informMessage = 'Select values and press \'set\''
            })
    }
    return (
        <div className={style.settingBlock}>
            <p>Max Value: <input
                className={settingCounter.minValue >= settingCounter.maxValue ? style.maxValueError : ''}
                type="number"
                onClick={() => {
                    onCheckValidationText();
                    setSettingCounter({...settingCounter, inSettingStatus: true})
                }}
                onChange={maxValueConfigHandler}
                value={settingCounter.maxValue}/>
            </p>
            <p>Min Value: <input
                className={valueValidator() ? style.minValueError : ''}
                type={'number'}
                onClick={() => {
                    onCheckValidationText();
                    setSettingCounter({...settingCounter, inSettingStatus: true})
                }}
                onChange={minValueConfigHandler}
                value={settingCounter.minValue}/>
            </p>
            <Button disabled={valueValidator} inSettingMode={!settingCounter.inSettingStatus} callback={setSettingValue}
                    title={'Set'}/>
        </div>
    );
};

export default Setting;